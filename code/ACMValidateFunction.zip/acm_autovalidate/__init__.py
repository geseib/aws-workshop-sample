"""
ACM Certificate with DNS Validation - AWS Lambda Function Init File
"""

from .index import handler